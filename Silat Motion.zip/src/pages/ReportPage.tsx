import React, { useState } from 'react';
import { Printer, Download } from 'lucide-react';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { mockSessions } from '../data/mockData';

// Logo UPI lokal untuk UI dan laporan PDF
const UpiLogo: React.FC<{ className?: string }> = ({ className = 'w-14 h-14' }) => (
  <img
    src="/upi-logo.png"
    alt="Logo Universitas Pendidikan Indonesia"
    className={`${className} object-contain shrink-0`}
    loading="eager"
  />
);

export const ReportPage: React.FC = () => {
  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-4 md:space-y-6 pb-20 md:pb-8 font-sans text-dark print:p-0 print:m-0">
      {/* Header halaman laporan */}
      <section className="print:hidden silat-hero relative overflow-hidden rounded-2xl text-slate-900 px-5 py-5 sm:px-7 sm:py-6 shadow-[0_14px_35px_rgba(128,0,0,.14)]">
        <div className="absolute -right-10 -top-16 w-48 h-48 rounded-full border border-[#800000]/10"/>
        <div className="absolute right-16 bottom-[-70px] w-40 h-40 rounded-full bg-[#800000]/[.025]"/>
        <div className="hero-content relative flex flex-col sm:flex-row sm:items-end justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="inline-flex items-center rounded-full bg-[#800000]/[.05] border border-[#800000]/10 px-2.5 py-1 text-[9px] font-bold tracking-wider uppercase">03 · Report</span>
              <span className="text-[9px] text-[#800000]/60">Silat Motion</span>
            </div>
            <h1 className="text-[23px] sm:text-[29px] font-extrabold tracking-[-.04em]">Laporan Hasil Analisis</h1>
            <p className="mt-1.5 text-[12px] sm:text-[13px] text-slate-600 max-w-xl">Rekapitulasi hasil pengukuran tendangan depan untuk dokumentasi penelitian.</p>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <Button className="!bg-[#800000] !text-white hover:!bg-[#650000] !rounded-xl !font-bold" size="sm" icon={<Printer size={14} />} onClick={handlePrint}>Cetak</Button>
            <Button className="!bg-[#800000]/[.05] !text-white hover:!bg-white/15 !border !border-[#800000]/10 !rounded-xl !font-bold" size="sm" icon={<Download size={14} />} onClick={handlePrint}>PDF</Button>
          </div>
        </div>
      </section>

      {/* Lembar Dokumen Rekomendasi Klinis */}
      <div className="bg-white border border-[#800000]/10 rounded-2xl shadow-xs p-4 sm:p-6 space-y-4 print:border-none print:shadow-none print:p-0">
        {/* Kop Surat Resmi */}
        <div className="border-b-2 border-[#800000] pb-3 flex items-center justify-between gap-3 sm:gap-4">
          <div className="shrink-0">
            <UpiLogo className="w-12 h-12 sm:w-14 sm:h-14" />
          </div>
          <div className="flex-1 text-center">
            <h2 className="text-[10px] sm:text-[11px] font-bold uppercase tracking-wider text-slate-500">
              Universitas Pendidikan Indonesia
            </h2>
            <h1 className="text-lg sm:text-xl font-black uppercase tracking-wider text-[#800000] leading-tight">
              SILAT-KICK
            </h1>
            <p className="text-[9.5px] sm:text-[10.5px] font-semibold text-slate-500">
              Divisi Monitoring & Evaluasi Pemulihan Atlet Pasca Cedera
            </p>
          </div>
          <div className="shrink-0 text-right font-mono text-[9px] text-slate-500">
            <span className="block font-bold text-[#800000] text-xs">ARSIP KLINIS</span>
            <span>{new Date().toLocaleDateString('id-ID')}</span>
          </div>
        </div>

        {/* Isi Rekomendasi */}
        <Card title="Ringkasan Evaluasi Kesiapan Atlet">
          <div className="p-3.5 sm:p-4 bg-slate-50 border border-slate-200/80 rounded-lg space-y-2.5 text-xs leading-relaxed text-slate-900">
            <p>
              Berdasarkan uji coba 5 tendangan depan pada sesi <b>{mockSessions[0].sessionCode}</b>, atlet{' '}
              <b>{mockSessions[0].athleteName}</b> menunjukkan kestabilan biomekanika dengan nilai akurasi rata-rata{' '}
              <b>88.4%</b> dan kecepatan rata-rata <b>14.2 m/s</b>.
            </p>
            <p className="text-emerald-700 font-semibold bg-emerald-50 border border-emerald-200 p-2.5 rounded-md">
              Kesimpulan: Atlet dinyatakan memenuhi kriteria fungsional untuk melanjutkan ke fase simulasi tanding (Return to Sport Ready).
            </p>
          </div>
        </Card>
      </div>
    </div>
  );
};