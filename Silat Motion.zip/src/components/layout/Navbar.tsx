import React from 'react';
import { UserRound, ShieldCheck, Search, Bell } from 'lucide-react';

export const Navbar: React.FC = () => <header className="h-[72px] bg-white/95 backdrop-blur border-b border-slate-200/80 px-5 lg:px-8 flex items-center justify-between sticky top-0 z-30">
  <div className="flex items-center gap-5 min-w-0 flex-1">
    <div className="hidden lg:flex relative w-full max-w-[470px]">
      <Search size={17} className="absolute left-4 top-3.5 text-slate-400" />
      <input placeholder="Cari atlet, kelas, atau kode..." className="w-full h-11 pl-11 pr-4 rounded-xl bg-slate-50 border border-slate-200 outline-none text-[12px] text-slate-700 placeholder:text-slate-400 focus:bg-white focus:border-[#800000]/30 transition" />
    </div>
    <div className="hidden lg:block min-w-0"><p className="text-[11px] font-bold text-slate-800 truncate">Analisis Akurasi & Kecepatan Tendangan Depan</p><p className="text-[9px] text-slate-400 mt-0.5">Sistem penelitian berbasis web · Pencak Silat UPI</p></div>
  </div>
  <div className="flex items-center gap-3 shrink-0"><div className="hidden sm:flex items-center gap-1.5 rounded-full bg-[#800000]/[.05] border border-[#800000]/10 px-2.5 py-1 text-[9px] font-semibold text-[#800000]"><ShieldCheck size={12}/> Research mode</div><button className="hidden sm:flex w-9 h-9 rounded-full items-center justify-center text-slate-500 hover:bg-slate-50"><Bell size={17}/></button><div className="w-9 h-9 rounded-full bg-[#800000]/[.08] border border-[#800000]/10 flex items-center justify-center text-[#800000] font-extrabold text-[11px]">AH</div><div className="hidden sm:block"><p className="text-[11px] font-bold text-slate-800">Muhammad Ahdan Haqqin</p><p className="text-[9px] text-slate-400">Peneliti</p></div></div>
</header>;
