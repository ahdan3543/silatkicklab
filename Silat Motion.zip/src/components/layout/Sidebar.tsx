import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import { Users, Activity, FileText, Menu, X, ChevronRight } from 'lucide-react';

const navItems = [
  { path:'/atlet', label:'Data Atlet', short:'Atlet', icon:Users, step:'01' },
  { path:'/analisis', label:'Analisis', short:'Analisis', icon:Activity, step:'02' },
  { path:'/laporan', label:'Laporan', short:'Laporan', icon:FileText, step:'03' },
];

const Brand = ({ mobile=false }: { mobile?: boolean }) => (
  <div className={`flex items-center ${mobile ? 'gap-2.5' : 'gap-3'}`}>
    <div className={`${mobile ? 'w-8 h-8' : 'w-10 h-10'} rounded-xl bg-white/10 border border-white/15 flex items-center justify-center overflow-hidden shrink-0`}>
      <img src="/silhouettes/dynamic.png" alt="" className="w-[145%] h-[145%] object-contain opacity-95" />
    </div>
    <div>
      <p className={`${mobile ? 'text-[13px]' : 'text-[15px]'} font-black tracking-tight text-white`}>SILAT MOTION</p>
      <p className="text-[9px] text-red-100/70">Analisis Tendangan Pencak Silat</p>
    </div>
  </div>
);

export const Sidebar: React.FC = () => {
  const [isOpen,setIsOpen]=useState(false);
  return <>
    <header className="md:hidden sticky top-0 z-40 h-14 px-4 bg-[#700000] flex items-center justify-between shadow-lg">
      <Brand mobile />
      <button onClick={()=>setIsOpen(!isOpen)} className="p-2 rounded-xl text-white hover:bg-white/10" aria-label="Buka menu">{isOpen?<X size={19}/>:<Menu size={19}/>}</button>
    </header>
    {isOpen && <div onClick={()=>setIsOpen(false)} className="fixed inset-0 bg-slate-950/45 z-40 md:hidden"/>}
    <aside className={`fixed md:sticky top-0 left-0 z-50 h-screen w-[254px] bg-gradient-to-b from-[#760000] via-[#680000] to-[#470000] text-white flex flex-col transition-transform duration-200 md:translate-x-0 overflow-hidden ${isOpen?'translate-x-0':'-translate-x-full'}`}>
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <img src="/silhouettes/high-kick.png" alt="" className="absolute -left-24 bottom-28 w-[390px] opacity-[.075] rotate-[-7deg]" />
        <img src="/silhouettes/kick.png" alt="" className="absolute -right-40 bottom-[-40px] w-[420px] opacity-[.045] rotate-[8deg]" />
      </div>
      <div className="relative p-5">
        <div className="pb-6 border-b border-white/10"><Brand /></div>
        <div className="mt-6 mb-3 px-2"><p className="text-[9px] font-bold uppercase tracking-[.2em] text-red-100/50">Research workflow</p></div>
        <nav className="space-y-2">
          {navItems.map(item=>{const Icon=item.icon; return <NavLink key={item.path} to={item.path} onClick={()=>setIsOpen(false)} className={({isActive})=>`group flex items-center gap-3 px-3.5 py-3.5 rounded-xl text-[13px] font-bold transition-all ${isActive?'bg-white/15 text-white shadow-[0_8px_24px_rgba(0,0,0,.18)] ring-1 ring-white/10':'text-red-50/80 hover:bg-white/10 hover:text-white'}`}>
            <span className="w-8 h-8 rounded-lg flex items-center justify-center bg-white/[.07]"><Icon size={17} strokeWidth={2}/></span>
            <span className="flex-1">{item.step}. {item.label}</span><ChevronRight size={14} className="opacity-40"/>
          </NavLink>})}
        </nav>
        <div className="mt-7 rounded-2xl border border-white/10 bg-black/10 p-4 backdrop-blur-sm">
          <div className="flex items-center gap-2"><span className="w-2 h-2 rounded-full bg-emerald-400 shadow-[0_0_0_4px_rgba(52,211,153,.12)]"/><p className="text-[10px] font-bold uppercase tracking-wider text-white/85">Mode penelitian</p></div>
          <p className="mt-2 text-[11px] leading-relaxed text-red-100/65">Subjek → video → pengukuran → hasil → laporan.</p>
        </div>
      </div>
      <div className="relative mt-auto px-5 py-5 border-t border-white/10 text-[9px] text-red-100/45">Riset Pencak Silat UPI · 2026</div>
    </aside>
    <nav className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-[#650000]/[.98] backdrop-blur border-t border-white/10 px-2 py-1.5 flex justify-around safe-area-bottom">
      {navItems.map(item=>{const Icon=item.icon; return <NavLink key={item.path} to={item.path} className={({isActive})=>`flex flex-col items-center py-1.5 px-5 rounded-xl text-[9px] font-semibold ${isActive?'text-white bg-white/10':'text-red-100/60'}`}><Icon size={17}/><span className="mt-0.5">{item.short}</span></NavLink>})}
    </nav>
  </>;
};
