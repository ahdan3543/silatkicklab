import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Plus, Search, Pencil, Trash2, Eye, Activity, UserRound, ArrowRight } from 'lucide-react';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Badge } from '../components/ui/Badge';
import { Athlete, AnalysisSession } from '../types';
import { athleteService } from '../services/athleteService';
import { sessionService } from '../services/sessionService';
import { AthleteFormModal } from '../features/athlete/AthleteFormModal';
import { AthleteDetailModal } from '../features/athlete/AthleteDetailModal';

export const AthletePage: React.FC = () => {
  const navigate = useNavigate();
  const [athletes, setAthletes] = useState<Athlete[]>([]);
  const [sessions, setSessions] = useState<AnalysisSession[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [formOpen, setFormOpen] = useState(false);
  const [detailOpen, setDetailOpen] = useState(false);
  const [editing, setEditing] = useState<Athlete | null>(null);
  const [selected, setSelected] = useState<Athlete | null>(null);
  const [deleting, setDeleting] = useState<Athlete | null>(null);

  const load = async () => {
    setLoading(true);
    try {
      const [a, s] = await Promise.all([athleteService.getAllAthletes(), sessionService.getAllSessions()]);
      setAthletes(a || []); setSessions(s || []);
    } finally { setLoading(false); }
  };
  useEffect(() => { load(); }, []);

  const filtered = athletes.filter(a => `${a.name} ${a.athleteCode}`.toLowerCase().includes(search.toLowerCase()));
  const sessionsFor = (id: string) => sessions.filter(s => s.athleteId === id).length;

  const remove = async () => {
    if (!deleting) return;
    if (sessions.some(s => s.athleteId === deleting.id)) {
      await athleteService.updateAthlete(deleting.id, { status: 'Tidak Aktif' });
    } else await athleteService.deleteAthlete(deleting.id);
    setDeleting(null); load();
  };

  return (
    <div className="max-w-6xl mx-auto space-y-5 pb-16 md:pb-0">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <p className="text-xs font-semibold text-[#800000]">TAHAP 1 • SUBJEK PENELITIAN</p>
          <h1 className="text-2xl md:text-3xl font-bold text-slate-900 mt-1">Data Atlet</h1>
          <p className="text-sm text-slate-500 mt-1 max-w-2xl">Tambahkan dan lengkapi identitas atlet yang menjadi subjek penelitian sebelum masuk ke tahap analisis.</p>
        </div>
        <Button variant="primary" icon={<Plus size={16} />} onClick={() => { setEditing(null); setFormOpen(true); }}>Tambah Atlet</Button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <Card className="p-4"><p className="text-xs text-slate-500">Subjek terdaftar</p><p className="text-2xl font-bold text-slate-900 mt-1">{athletes.length}</p></Card>
        <Card className="p-4"><p className="text-xs text-slate-500">Atlet aktif</p><p className="text-2xl font-bold text-slate-900 mt-1">{athletes.filter(a => a.status === 'Aktif').length}</p></Card>
        <Card className="p-4"><p className="text-xs text-slate-500">Sesi analisis</p><p className="text-2xl font-bold text-slate-900 mt-1">{sessions.length}</p></Card>
      </div>

      <Card className="p-4 sm:p-5">
        <div className="flex flex-col sm:flex-row gap-3 justify-between mb-4">
          <div><h2 className="text-base font-semibold text-slate-900">Daftar Subjek</h2><p className="text-xs text-slate-500 mt-0.5">Pilih atlet untuk memulai analisis tendangan depan.</p></div>
          <div className="relative w-full sm:w-72">
            <Search size={16} className="absolute left-3 top-2.5 text-slate-400" />
            <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Cari nama atau kode atlet..." className="w-full pl-9 pr-3 py-2 text-sm border border-slate-200 rounded-lg outline-none focus:border-[#800000]" />
          </div>
        </div>

        {loading ? <p className="py-10 text-center text-sm text-slate-500">Memuat data atlet...</p> : filtered.length === 0 ? (
          <div className="py-12 text-center border border-dashed border-slate-200 rounded-lg"><UserRound className="mx-auto text-slate-300" size={34}/><p className="mt-3 text-sm font-medium text-slate-700">Belum ada atlet</p><p className="text-xs text-slate-500 mt-1">Tambahkan subjek penelitian untuk memulai.</p><button onClick={() => { setEditing(null); setFormOpen(true); }} className="mt-4 text-sm font-semibold text-[#800000]">+ Tambah atlet pertama</button></div>
        ) : (
          <div className="divide-y divide-slate-100">
            {filtered.map(a => (
              <div key={a.id} className="py-4 flex flex-col lg:flex-row lg:items-center gap-4">
                <div className="flex items-center gap-3 flex-1 min-w-0">
                  <div className="w-11 h-11 rounded-full bg-[#800000]/10 text-[#800000] flex items-center justify-center font-bold shrink-0">{a.name.slice(0,2).toUpperCase()}</div>
                  <div className="min-w-0"><p className="font-semibold text-slate-900 truncate">{a.name}</p><p className="text-xs text-slate-500">{a.athleteCode} • {a.age ?? '-'} tahun • {a.gender}</p></div>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs min-w-0 lg:w-[48%]">
                  <div><p className="text-slate-400">Kelas</p><p className="font-medium text-slate-700 truncate">{a.category || '-'}</p></div>
                  <div><p className="text-slate-400">Kaki dominan</p><p className="font-medium text-slate-700">{a.dominantLeg}</p></div>
                  <div><p className="text-slate-400">Cedera</p><p className="font-medium text-slate-700">{a.injuredLeg ? `${a.injuredLeg} • ${a.injuryType || 'Tidak dicatat'}` : 'Tidak ada'}</p></div>
                  <div><p className="text-slate-400">Sesi</p><p className="font-medium text-slate-700">{sessionsFor(a.id)} kali</p></div>
                </div>
                <div className="flex items-center gap-1 lg:ml-auto">
                  <Badge variant={a.status === 'Aktif' ? 'success' : 'neutral'}>{a.status || 'Aktif'}</Badge>
                  <button title="Detail" onClick={() => { setSelected(a); setDetailOpen(true); }} className="p-2 rounded-lg hover:bg-slate-100 text-slate-500"><Eye size={16}/></button>
                  <button title="Edit" onClick={() => { setEditing(a); setFormOpen(true); }} className="p-2 rounded-lg hover:bg-slate-100 text-slate-500"><Pencil size={16}/></button>
                  <button title="Hapus" onClick={() => setDeleting(a)} className="p-2 rounded-lg hover:bg-red-50 text-red-500"><Trash2 size={16}/></button>
                  <button onClick={() => navigate(`/analisis?athlete=${encodeURIComponent(a.id)}`)} className="ml-1 inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-[#800000] text-white text-xs font-semibold hover:bg-[#680000]"><Activity size={15}/> Analisis <ArrowRight size={14}/></button>
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>

      <AthleteFormModal isOpen={formOpen} initialData={editing} onClose={() => setFormOpen(false)} onSuccess={() => { setFormOpen(false); load(); }} />
      <AthleteDetailModal isOpen={detailOpen} athlete={selected} onClose={() => setDetailOpen(false)} />

      {deleting && <div className="fixed inset-0 z-[60] bg-slate-900/40 flex items-center justify-center p-4"><div className="bg-white rounded-xl p-5 w-full max-w-sm shadow-xl"><h3 className="font-semibold text-slate-900">Hapus atlet?</h3><p className="text-sm text-slate-500 mt-2">Data <b>{deleting.name}</b> akan dihapus jika belum memiliki sesi analisis.</p><div className="flex justify-end gap-2 mt-5"><Button variant="outline" onClick={() => setDeleting(null)}>Batal</Button><Button variant="primary" onClick={remove}>Hapus</Button></div></div></div>}
    </div>
  );
};
