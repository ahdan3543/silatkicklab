import React, { useEffect, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { Plus, Activity, ArrowRight, Trash2, FileText, CheckCircle2 } from 'lucide-react';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Badge } from '../components/ui/Badge';
import { AnalysisSession, Athlete } from '../types';
import { sessionService } from '../services/sessionService';
import { athleteService } from '../services/athleteService';
import { SessionFormModal } from '../features/analysis/SessionFormModal';

export const AnalysisPage: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [sessions, setSessions] = useState<AnalysisSession[]>([]);
  const [athletes, setAthletes] = useState<Athlete[]>([]);
  const [loading, setLoading] = useState(true);
  const [formOpen, setFormOpen] = useState(false);
  const [deleteId, setDeleteId] = useState<string | null>(null);

  const params = new URLSearchParams(location.search);
  const initialAthleteId = params.get('athlete') || undefined;

  const load = async () => {
    setLoading(true);
    try {
      const [s, a] = await Promise.all([sessionService.getAllSessions(), athleteService.getAllAthletes()]);
      setSessions(s || []); setAthletes(a || []);
    } finally { setLoading(false); }
  };
  useEffect(() => { load(); }, []);
  useEffect(() => { if (initialAthleteId) setFormOpen(true); }, [initialAthleteId]);

  const athlete = (id: string) => athletes.find(a => a.id === id);
  const remove = async () => { if (deleteId) await sessionService.deleteSession(deleteId); setDeleteId(null); load(); };

  return (
    <div className="max-w-6xl mx-auto space-y-5 pb-16 md:pb-0">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <p className="text-xs font-semibold text-[#800000]">TAHAP 2 • PENGAMBILAN DATA</p>
          <h1 className="text-2xl md:text-3xl font-bold text-slate-900 mt-1">Analisis Tendangan Depan</h1>
          <p className="text-sm text-slate-500 mt-1 max-w-2xl">Buat sesi untuk atlet yang sudah terdaftar, lalu lakukan pengujian 5 percobaan menggunakan video dari sudut samping.</p>
        </div>
        <Button variant="primary" icon={<Plus size={16}/>} onClick={() => setFormOpen(true)}>Sesi Analisis Baru</Button>
      </div>

      <Card className="p-4 sm:p-5 border-[#800000]/15 bg-[#800000]/[0.025]">
        <div className="flex items-start gap-3"><div className="p-2 rounded-lg bg-[#800000]/10 text-[#800000]"><Activity size={18}/></div><div><p className="text-sm font-semibold text-slate-800">Protokol penelitian</p><p className="text-xs leading-relaxed text-slate-500 mt-1">Setiap sesi berisi maksimal 5 percobaan tendangan depan. Hasil akurasi dan kecepatan menjadi dasar laporan penelitian.</p></div></div>
      </Card>

      <Card className="p-4 sm:p-5">
        <div className="flex items-center justify-between mb-4"><div><h2 className="text-base font-semibold text-slate-900">Sesi Analisis</h2><p className="text-xs text-slate-500 mt-0.5">Riwayat pengujian yang sudah dibuat.</p></div><span className="text-xs text-slate-500">{sessions.length} sesi</span></div>
        {loading ? <p className="py-10 text-center text-sm text-slate-500">Memuat sesi...</p> : sessions.length === 0 ? (
          <div className="py-12 text-center border border-dashed border-slate-200 rounded-lg"><Activity className="mx-auto text-slate-300" size={34}/><p className="mt-3 text-sm font-medium text-slate-700">Belum ada sesi analisis</p><p className="text-xs text-slate-500 mt-1">Pilih atlet dari tahap Data Atlet untuk memulai.</p><button onClick={() => navigate('/atlet')} className="mt-4 inline-flex items-center gap-1 text-sm font-semibold text-[#800000]">Kembali ke Data Atlet <ArrowRight size={14}/></button></div>
        ) : (
          <div className="divide-y divide-slate-100">
            {sessions.map(s => { const a = athlete(s.athleteId); const done = s.attempts.filter(x => x.video || x.status === 'Dianalisis').length; return (
              <div key={s.id} className="py-4 flex flex-col md:flex-row md:items-center gap-4">
                <div className="flex-1"><div className="flex items-center gap-2"><p className="font-semibold text-slate-900">{s.athleteName || a?.name || '-'}</p><Badge variant={s.status === 'Selesai' || s.status === 'Completed' ? 'success' : 'info'}>{s.status || 'Draft'}</Badge></div><p className="text-xs text-slate-500 mt-1">{s.sessionCode} • {s.date} • Kaki diuji: {s.kickingLeg}</p></div>
                <div className="text-xs text-slate-500">Percobaan <b className="text-slate-800">{done}/5</b></div>
                <div className="flex gap-1"><button onClick={() => setDeleteId(s.id)} className="p-2 rounded-lg hover:bg-red-50 text-red-500"><Trash2 size={16}/></button><button onClick={() => navigate(`/analisis/${s.id}`)} className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-[#800000] text-white text-xs font-semibold"><span>{done ? 'Lanjut Analisis' : 'Buka Sesi'}</span><ArrowRight size={14}/></button>{(s.status === 'Selesai' || s.status === 'Completed') && <button onClick={() => navigate(`/analisis/${s.id}/laporan`)} className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border border-slate-200 text-xs font-semibold text-slate-700"><FileText size={14}/> Laporan</button>}</div>
              </div>
            ); })}
          </div>
        )}
      </Card>

      <SessionFormModal isOpen={formOpen} initialAthleteId={initialAthleteId} onClose={() => { setFormOpen(false); if (initialAthleteId) navigate('/analisis', { replace: true }); }} onSuccess={(id) => { setFormOpen(false); if (id) navigate(`/analisis/${id}`); else load(); }} />

      {deleteId && <div className="fixed inset-0 z-[60] bg-slate-900/40 flex items-center justify-center p-4"><div className="bg-white rounded-xl p-5 w-full max-w-sm shadow-xl"><h3 className="font-semibold text-slate-900">Hapus sesi analisis?</h3><p className="text-sm text-slate-500 mt-2">Data sesi dan hubungan pengujiannya akan dihapus.</p><div className="flex justify-end gap-2 mt-5"><Button variant="outline" onClick={() => setDeleteId(null)}>Batal</Button><Button variant="primary" onClick={remove}>Hapus</Button></div></div></div>}
    </div>
  );
};
