import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import { Users, Activity, FileText, Menu, X, ChevronRight } from 'lucide-react';

const UpiLogo: React.FC<{ className?: string }> = ({ className = 'w-9 h-9' }) => (
  <img
    src="/upi-logo.png"
    alt="Logo Universitas Pendidikan Indonesia"
    className={`${className} object-contain shrink-0`}
    loading="eager"
  />
);

const navItems = [
  { path: '/atlet', label: '1. Data Atlet', short: 'Atlet', icon: Users },
  { path: '/analisis', label: '2. Analisis', short: 'Analisis', icon: Activity },
  { path: '/laporan', label: '3. Laporan', short: 'Laporan', icon: FileText },
];

export const Sidebar: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <>
      <header className="md:hidden sticky top-0 z-40 flex items-center justify-between px-4 py-3 bg-white border-b border-slate-200">
        <div className="flex items-center gap-2.5">
          <UpiLogo className="w-9 h-9" />
          <div>
            <p className="text-sm font-bold text-slate-900 leading-tight">SILAT MOTION</p>
            <p className="text-[10px] text-slate-500">Analisis Tendangan Depan</p>
          </div>
        </div>
        <button onClick={() => setIsOpen(!isOpen)} className="p-2 rounded-lg hover:bg-slate-100" aria-label="Buka menu">
          {isOpen ? <X size={21} /> : <Menu size={21} />}
        </button>
      </header>

      {isOpen && <div onClick={() => setIsOpen(false)} className="fixed inset-0 bg-slate-900/40 z-40 md:hidden" />}

      <aside className={`fixed md:sticky top-0 left-0 z-50 h-screen w-64 bg-white border-r border-slate-200 flex flex-col transition-transform duration-200 md:translate-x-0 ${isOpen ? 'translate-x-0' : '-translate-x-full'}`}>
        <div className="p-5">
          <div className="flex items-center gap-3 pb-5 border-b border-slate-100">
            <UpiLogo className="w-10 h-10" />
            <div>
              <h1 className="text-[15px] font-bold tracking-tight text-slate-900">SILAT MOTION</h1>
              <p className="text-[10px] text-slate-500 leading-tight">Universitas Pendidikan Indonesia</p>
            </div>
          </div>

          <div className="mt-6 mb-3 px-3">
            <p className="text-[10px] font-semibold uppercase tracking-wider text-slate-400">Tahapan Penelitian</p>
          </div>

          <nav className="space-y-1.5">
            {navItems.map((item) => {
              const Icon = item.icon;
              return (
                <NavLink
                  key={item.path}
                  to={item.path}
                  onClick={() => setIsOpen(false)}
                  className={({ isActive }) => `flex items-center gap-3 px-3.5 py-3 rounded-lg text-sm font-medium transition-colors ${isActive ? 'bg-[#800000] text-white' : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'}`}
                >
                  <Icon size={18} strokeWidth={1.9} />
                  <span className="flex-1">{item.label}</span>
                  <ChevronRight size={14} className="opacity-40" />
                </NavLink>
              );
            })}
          </nav>

          <div className="mt-8 rounded-lg border border-slate-200 bg-slate-50 p-3.5">
            <p className="text-xs font-semibold text-slate-700">Alur pengujian</p>
            <p className="mt-1 text-[11px] leading-relaxed text-slate-500">Daftarkan atlet → lakukan analisis 5 percobaan → cetak laporan hasil penelitian.</p>
          </div>
        </div>

        <div className="mt-auto p-4 border-t border-slate-100 text-[10px] text-slate-400 text-center">
          Riset Pencak Silat UPI © 2026
        </div>
      </aside>

      <nav className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white border-t border-slate-200 px-2 py-1.5 flex justify-around">
        {navItems.map((item) => {
          const Icon = item.icon;
          return (
            <NavLink key={item.path} to={item.path} className={({ isActive }) => `flex flex-col items-center py-1 px-4 rounded-lg text-[10px] font-medium ${isActive ? 'text-[#800000]' : 'text-slate-500'}`}>
              <Icon size={18} />
              <span className="mt-0.5">{item.short}</span>
            </NavLink>
          );
        })}
      </nav>
    </>
  );
};
