import React from 'react';
import { User } from 'lucide-react';

export const Navbar: React.FC = () => (
  <header className="h-16 bg-white border-b border-slate-200 px-8 flex items-center justify-between sticky top-0 z-30">
    <div>
      <h2 className="text-sm font-semibold text-slate-800">Analisis Akurasi dan Kecepatan Tendangan Depan</h2>
      <p className="text-[10px] text-slate-500 mt-0.5">Sistem penelitian berbasis web • Pencak Silat UPI</p>
    </div>
    <div className="flex items-center gap-2.5">
      <div className="w-8 h-8 rounded-full bg-[#800000]/10 border border-[#800000]/15 flex items-center justify-center text-[#800000]">
        <User size={16} />
      </div>
      <div className="text-left">
        <p className="text-xs font-semibold text-slate-800">Peneliti</p>
        <p className="text-[10px] text-slate-500">Evaluator / Peneliti</p>
      </div>
    </div>
  </header>
);
