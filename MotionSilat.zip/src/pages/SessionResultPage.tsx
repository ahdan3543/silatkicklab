import React, { useState, useEffect, useMemo } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  ArrowLeft,
  CheckCircle2,
  XCircle,
  AlertCircle,
  ArrowUpRight,
  FileText,
  Zap,
  Target,
  Clock,
  Activity,
  Award,
} from 'lucide-react';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Badge } from '../components/ui/Badge';
import { Table } from '../components/ui/Table';
import { LoadingState } from '../components/ui/LoadingState';
import { AccuracyDistanceChart } from '../features/analysis/AccuracyDistanceChart';
import { ValidationPanel } from '../features/analysis/ValidationPanel';
import { AnalysisSession, Athlete } from '../types';
import { PoseAnalysisResult } from '../types/pose';
import { SpeedAnalysisResult } from '../types/speed';
import { TargetDefinition, AccuracyAnalysisResult } from '../types/accuracy';
import { SessionQualityReport } from '../types/validation';
import { sessionService } from '../services/sessionService';
import { athleteService } from '../services/athleteService';
import { poseStorageService } from '../services/videoAnalysis/poseStorageService';
import { speedStorageService } from '../services/speed/speedStorageService';
import { accuracyStorageService } from '../services/accuracy/accuracyStorageService';
import { validationService } from '../services/validation/validationService';
import {
  sessionSummaryEngine,
  SessionAggregatedSummary,
  MergedAttemptResult,
} from '../services/result/sessionSummaryEngine';

// Grafik ringkas 3 parameter kecepatan.
const ModernSpeedComparisonChart: React.FC<{
  attempts: MergedAttemptResult[];
  speedUnit: string;
}> = ({ attempts, speedUnit }) => {
  const series = [
    { key: 'phase', label: 'Start → Impact', short: 'Fase Tendangan', color: '#800000', get: (a: MergedAttemptResult) => a.averageSpeed },
    { key: 'cycle', label: 'Siklus Penuh', short: 'Start → Recovery', color: '#0F766E', get: (a: MergedAttemptResult) => a.fullCycleAverageSpeed },
    { key: 'peak', label: 'Kecepatan Puncak', short: 'Nilai maksimum', color: '#D4A017', get: (a: MergedAttemptResult) => a.peakSpeed },
  ];

  const MiniChart: React.FC<{ item: typeof series[number] }> = ({ item }) => {
    const values = attempts.map((a) => item.get(a) || 0).filter((v) => v > 0 && v < 35);
    const maxVal = Math.max(5, Math.ceil((values.length ? Math.max(...values) : 5) * 1.2));
    const width = 260;
    const height = 118;
    const left = 28;
    const right = 10;
    const top = 12;
    const bottom = 24;
    const plotW = width - left - right;
    const plotH = height - top - bottom;
    const getY = (v: number) => height - bottom - (Math.min(v, maxVal) / maxVal) * plotH;
    const groupW = plotW / Math.max(attempts.length, 1);

    return (
      <div className="rounded-xl border border-dark-border bg-slate-50/60 p-3">
        <div className="flex items-start justify-between gap-2 mb-1">
          <div>
            <p className="text-[11px] font-bold text-dark">{item.label}</p>
            <p className="text-[9px] text-dark-secondary">{item.short}</p>
          </div>
          <span className="text-[9px] font-mono font-bold px-1.5 py-0.5 rounded bg-white border border-dark-border">{speedUnit}</span>
        </div>
        <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-28 overflow-visible">
          <line x1={left} y1={top} x2={width-right} y2={top} stroke="#E2E8F0" strokeDasharray="3 3" />
          <line x1={left} y1={height-bottom} x2={width-right} y2={height-bottom} stroke="#CBD5E1" />
          <text x={left-5} y={top+3} fill="#94A3B8" fontSize="7" textAnchor="end">{maxVal}</text>
          <text x={left-5} y={height-bottom+3} fill="#94A3B8" fontSize="7" textAnchor="end">0</text>
          {attempts.map((att, idx) => {
            const value = item.get(att) || 0;
            const x = left + idx * groupW + groupW/2 - 8;
            const y = getY(value);
            const h = Math.max(0, height-bottom-y);
            return <g key={att.attemptId || idx}>
              {value > 0 && <>
                <rect x={x} y={y} width="16" height={h} rx="3" fill={item.color} />
                <text x={x+8} y={y-4} fill={item.color} fontSize="7" textAnchor="middle" fontWeight="bold">{value.toFixed(1)}</text>
              </>}
              <text x={left + idx * groupW + groupW/2} y={height-9} fill="#64748B" fontSize="7.5" textAnchor="middle" fontWeight="bold">P#{att.attemptNumber || idx+1}</text>
            </g>;
          })}
        </svg>
      </div>
    );
  };

  return (
    <div className="w-full bg-white border border-dark-border rounded-2xl shadow-xs p-4">
      <div className="flex items-center justify-between gap-2 mb-3">
        <div>
          <h3 className="font-bold text-dark text-sm">Grafik Kecepatan</h3>
          <p className="text-[10px] text-dark-secondary mt-0.5">Tiga parameter kecepatan pada 5 percobaan</p>
        </div>
        <span className="text-[9px] font-mono font-bold text-[#800000] bg-[#800000]/10 border border-[#800000]/20 px-2 py-1 rounded-lg">{speedUnit}</span>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        {series.map((item) => <MiniChart key={item.key} item={item} />)}
      </div>
    </div>
  );
};

export const SessionResultPage: React.FC = () => {
  const { sessionId } = useParams<{ sessionId: string }>();
  const navigate = useNavigate();

  const [session, setSession] = useState<AnalysisSession | null>(null);
  const [athlete, setAthlete] = useState<Athlete | null>(null);
  const [target, setTarget] = useState<TargetDefinition | null>(null);
  const [summary, setSummary] = useState<SessionAggregatedSummary | null>(null);
  const [qualityReport, setQualityReport] = useState<SessionQualityReport | null>(null);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    const loadSessionResults = async () => {
      if (!sessionId) return;
      try {
        setLoading(true);
        const ses = await sessionService.getSessionById(sessionId);
        if (!ses) return;
        setSession(ses);

        const [ath, tar] = await Promise.all([
          athleteService.getAthleteById(ses.athleteId),
          accuracyStorageService.getTargetBySessionId(sessionId),
        ]);

        if (ath) setAthlete(ath);
        if (tar) setTarget(tar);

        const poseMap: { [videoId: string]: PoseAnalysisResult } = {};
        const spdMap: { [videoId: string]: SpeedAnalysisResult } = {};
        const accMap: { [videoId: string]: AccuracyAnalysisResult } = {};

        for (const att of ses.attempts) {
          if (att.video) {
            const [p, s, a] = await Promise.all([
              poseStorageService.getPoseResultByVideoId(att.video.id),
              speedStorageService.getSpeedResultByVideoId(att.video.id),
              accuracyStorageService.getAccuracyResultByVideoId(att.video.id),
            ]);
            if (p) poseMap[att.video.id] = p;
            if (s) spdMap[att.video.id] = s;
            if (a) accMap[att.video.id] = a;
          }
        }

        const aggregated = sessionSummaryEngine.aggregateSessionResults(
          ses.attempts,
          spdMap,
          accMap
        );
        setSummary(aggregated);

        const validationRes = validationService.validateSessionQuality(
          ses,
          ath || null,
          tar || null,
          poseMap,
          spdMap,
          accMap
        );
        setQualityReport(validationRes);
      } catch (err) {
        console.error('Gagal memuat halaman hasil sesi:', err);
      } finally {
        setLoading(false);
      }
    };

    loadSessionResults();
  }, [sessionId]);

  const accuracyResultsList: AccuracyAnalysisResult[] = useMemo(() => {
    return summary
      ? summary.attempts
          .map((a) => a.accuracyResult)
          .filter((r): r is AccuracyAnalysisResult => r !== null)
      : [];
  }, [summary]);

  if (loading) {
    return <LoadingState message="Menghitung rekapitulasi data hasil dan validasi sistem..." />;
  }

  if (!session) {
    return (
      <div className="text-center py-12 space-y-4">
        <p className="text-dark-secondary text-sm">Sesi analisis tidak ditemukan.</p>
        <Button onClick={() => navigate('/hasil')}>Kembali ke Daftar Hasil</Button>
      </div>
    );
  }

  return (
    <div id="analysis-report" className="space-y-5 pb-24 md:pb-8">
      {/* 1. Header Hero Maroon UPI */}
      <div className="relative overflow-hidden bg-gradient-to-r from-[#700000] via-[#800000] to-[#991B1B] rounded-2xl p-5 text-white shadow-md">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <button
              onClick={() => navigate(`/analisis/${session.id}`)}
              className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-colors shrink-0"
              title="Kembali ke Ruang Analisis"
            >
              <ArrowLeft size={18} />
            </button>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-[#FACC15] text-[#700000] text-[10px] font-black uppercase tracking-wider">
                  <Award size={12} className="stroke-[2.5]" />
                  Hasil Evaluasi Sesi
                </span>
                <span className="font-mono text-xs text-white/70">{session.sessionCode}</span>
              </div>
              <h1 className="text-lg md:text-xl font-black text-white mt-1">
                Rekapitulasi Evaluasi 5 Percobaan
              </h1>
              <p className="text-xs text-white/80">
                Subjek: <b>{athlete?.name || session.athleteName}</b> • Kaki Uji: <b>Tendangan {session.kickingLeg}</b>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <Button
              variant="outline"
              size="sm"
              className="bg-white/10 hover:bg-white/20 text-white border-white/20 text-xs"
              icon={<ArrowUpRight size={14} />}
              onClick={() => navigate(`/analisis/${session.id}`)}
            >
              Ruang Analisis
            </Button>
            <Button
              variant="primary"
              size="sm"
              className="bg-[#FACC15] hover:bg-[#EAB308] text-slate-950 font-bold border-none text-xs"
              icon={<FileText size={14} />}
              onClick={() => navigate(`/analisis/${session.id}/laporan`)}
            >
              Cetak Laporan PDF
            </Button>
          </div>
        </div>
      </div>

      {/* 2. Panel Validasi Sistem */}
      <ValidationPanel qualityReport={qualityReport} />

      {/* 3. Ringkasan 3 Parameter Kecepatan */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        <Card className="p-4 border-l-4 border-l-emerald-600 shadow-sm">
          <span className="text-[11px] font-semibold text-dark-secondary uppercase tracking-wider block">Akurasi Sasaran</span>
          <div className="mt-1 flex items-baseline gap-2">
            <h3 className="text-2xl font-black font-mono text-emerald-800">{summary?.accuracyPercentage != null ? `${summary.accuracyPercentage.toFixed(1)}%` : '--'}</h3>
            <span className="text-xs font-bold text-emerald-700">{summary ? `${summary.hitsCount}/${summary.validAttempts} HIT` : ''}</span>
          </div>
          <p className="text-[11px] text-dark-secondary mt-1">Ketepatan terhadap target</p>
        </Card>

        <Card className="p-4 border-l-4 border-l-[#800000] shadow-sm">
          <span className="text-[11px] font-semibold text-dark-secondary uppercase tracking-wider block">Kecepatan Puncak</span>
          <h3 className="text-2xl font-black font-mono text-[#800000] mt-1">{summary?.sessionPeakSpeed != null ? `${summary.sessionPeakSpeed.toFixed(2)} ${summary.speedUnit}` : '--'}</h3>
          <p className="text-[10px] text-dark-secondary mt-1">Maksimum yang tercatat selama gerakan</p>
        </Card>

        <Card className="p-4 border-l-4 border-l-sky-500 shadow-sm">
          <span className="text-[11px] font-semibold text-dark-secondary uppercase tracking-wider block">Kecepatan Rata-rata Fase Tendangan</span>
          <h3 className="text-2xl font-black font-mono text-dark mt-1">{summary?.sessionAverageSpeed != null ? `${summary.sessionAverageSpeed.toFixed(2)} ${summary.speedUnit}` : '--'}</h3>
          <p className="text-[10px] text-dark-secondary mt-1"><span className="font-mono font-semibold text-dark">{summary?.sessionAverageDuration != null ? `${summary.sessionAverageDuration.toFixed(2)} s` : '--'}</span> · waktu Start → Impact</p>
        </Card>

        <Card className="p-4 border-l-4 border-l-teal-600 shadow-sm">
          <span className="text-[11px] font-semibold text-dark-secondary uppercase tracking-wider block">Kecepatan Rata-rata Siklus Penuh</span>
          <h3 className="text-2xl font-black font-mono text-teal-800 mt-1">{summary?.sessionFullCycleAverageSpeed != null ? `${summary.sessionFullCycleAverageSpeed.toFixed(2)} ${summary.speedUnit}` : '--'}</h3>
          <p className="text-[10px] text-dark-secondary mt-1"><span className="font-mono font-semibold text-dark">{summary?.attempts.filter(a => a.fullCycleDuration != null).length ? `${(summary.attempts.filter(a => a.fullCycleDuration != null).reduce((sum,a) => sum + (a.fullCycleDuration || 0), 0) / summary.attempts.filter(a => a.fullCycleDuration != null).length).toFixed(2)} s` : '--'}</span> · durasi Start → Recovery</p>
        </Card>
      </div>

      {/* 4. Tabel 5 Percobaan Lengkap */}
      <Card
        title="Rekapitulasi 5 Percobaan Tendangan Depan"
        subtitle="Perbandingan Parameter Kecepatan dan Akurasi"
      >
        <Table
          headers={[
            'PERCOBAAN',
            'FASE START–IMPACT',
            'SIKLUS PENUH',
            'PUNCAK',
            'DEVIASI TARGET',
            'STATUS',
            'METODE',
            'AKSI',
          ]}
        >
          {summary?.attempts.map((att) => {
            const isHit = att.status === 'HIT';
            const isMiss = att.status === 'MISS';
            const isInvalid = att.status === 'INVALID';

            return (
              <tr key={att.attemptId} className="text-xs hover:bg-slate-50/80 transition-colors">
                <td className="px-4 py-3 font-bold text-dark">
                  Percobaan #{att.attemptNumber}
                </td>
                <td className="px-4 py-3 font-mono text-dark">{att.averageSpeed !== null ? <><div>{att.averageSpeed.toFixed(2)} {att.speedUnit}</div><div className="text-[9px] text-dark-secondary font-sans mt-0.5">{att.kickDuration != null ? `${att.kickDuration.toFixed(2)} s` : '--'} · waktu fase</div></> : '-'}</td>
                <td className="px-4 py-3 font-mono text-dark">{att.fullCycleAverageSpeed !== null ? <><div>{att.fullCycleAverageSpeed.toFixed(2)} {att.speedUnit}</div><div className="text-[9px] text-dark-secondary font-sans mt-0.5">{att.fullCycleDuration != null ? `${att.fullCycleDuration.toFixed(2)} s` : '--'} · durasi siklus</div></> : '-'}</td>
                <td className="px-4 py-3 font-mono font-bold text-[#800000]">{att.peakSpeed !== null ? `${att.peakSpeed.toFixed(2)} ${att.speedUnit}` : '-'}</td>
                <td className="px-4 py-3 font-mono text-dark">
                  {att.distanceToTargetCm !== null ? `${att.distanceToTargetCm.toFixed(1)} cm` : '-'}
                </td>
                <td className="px-4 py-3">
                  {isHit && (
                    <span className="inline-flex items-center gap-1 text-emerald-800 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded font-bold text-[11px]">
                      <CheckCircle2 size={12} className="text-emerald-600" /> HIT
                    </span>
                  )}
                  {isMiss && (
                    <span className="inline-flex items-center gap-1 text-rose-800 bg-rose-50 border border-rose-200 px-2 py-0.5 rounded font-bold text-[11px]">
                      <XCircle size={12} className="text-rose-600" /> MISS
                    </span>
                  )}
                  {isInvalid && (
                    <span className="inline-flex items-center gap-1 text-amber-800 bg-amber-50 border border-amber-200 px-2 py-0.5 rounded font-bold text-[11px]">
                      <AlertCircle size={12} className="text-amber-600" /> INVALID
                    </span>
                  )}
                  {att.status === 'BELUM_DIANALISIS' && (
                    <span className="text-dark-secondary text-[11px]">-</span>
                  )}
                </td>
                <td className="px-4 py-3 text-[11px] text-dark-secondary">
                  {att.isManualCorrected ? 'Manual Corrected' : 'Otomatis'}
                </td>
                <td className="px-4 py-3">
                  {att.hasVideo ? (
                    <button
                      onClick={() => navigate(`/analisis/${session.id}/attempt/${att.attemptId}`)}
                      className="font-bold text-[#800000] hover:underline inline-flex items-center gap-1"
                    >
                      Review <ArrowUpRight size={12} />
                    </button>
                  ) : (
                    <span className="text-dark-secondary text-[11px]">-</span>
                  )}
                </td>
              </tr>
            );
          })}
        </Table>
      </Card>

      {/* 5. Grafik Komparasi Bersih Sejajar (Card ganda sudah dilepas) */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 md:gap-6 items-stretch">
        {summary && (
          <ModernSpeedComparisonChart
            attempts={summary.attempts}
            speedUnit={summary.speedUnit}
          />
        )}
        <AccuracyDistanceChart results={accuracyResultsList} />
      </div>
    </div>
  );
};